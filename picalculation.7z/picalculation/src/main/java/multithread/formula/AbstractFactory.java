/*
 * 
 */
package multithread.formula;

public abstract class AbstractFactory {
	
	/**
	 * Gets the pi.
	 *
	 * @param input the input
	 * @param nThreads the n threads
	 * @param lowerBound the lower bound
	 * @return the pi
	 */
	abstract GregoryLeibniz getPi(long input, int nThreads, double lowerBound);
}
