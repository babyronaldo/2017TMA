package multithread.formula;

public abstract class AbstractFactory {
	abstract GregoryLeibniz getPi(long input, int nThreads);
}
