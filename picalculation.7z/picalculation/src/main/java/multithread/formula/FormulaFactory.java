package multithread.formula;

public class FormulaFactory extends AbstractFactory {

	@Override
	public GregoryLeibniz getPi(long input, int nThreads, double lowerBound) {

		if (input <= 0) {
			System.out.println("Factory input: " + input);
			System.out.println("Wrong!!!");
			return null;
		} else {
			GregoryLeibniz gregoryLeibniz = new GregoryLeibniz(input, nThreads, lowerBound);
			gregoryLeibniz.GregoryLeibnizFormula(input, nThreads);
			return gregoryLeibniz;
		}
	}
}
