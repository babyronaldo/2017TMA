package multithread.formula;

public class FormulaFactory extends AbstractFactory {

	@Override
	public GregoryLeibniz getPi(long input, int nThreads) {

		if (input <= 0) {
			System.out.println("Factory input: " + input);
			System.out.println("Wrong!!!");
			return null;
		} else
			return new GregoryLeibniz(input, nThreads);
	}
}
