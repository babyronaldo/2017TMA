package multithread.formula;

import multithread.interfaces.PiFormula;

public class GregoryLeibniz implements PiFormula {

	double count = 0.0;
	private long input;
	private double lowerBound;
	int nThreads;

	public GregoryLeibniz(long input, int nThreads) {
		super();

		this.input = input;
		this.nThreads = nThreads;
	}

	public void GregoryLeibnizFormula(long input, int nThreads) {
		if (input <= 0)
			System.out.println("Your input is invalid");
		else {
			for (double i = lowerBound; i < lowerBound + input / nThreads; i++) {
				count += Math.pow(-1, i) / (2 * i + 1);
			}
		}
	}

	public double getSum() {
		return count;
	}

}
