/*
 * 
 */
package multithread.formula;

import multithread.interfaces.PiFormula;

public class GregoryLeibniz implements PiFormula {

    /** The count. */
    private double count = 0.0;

    /** The lower bound. */
    private double lowerBound;

    /**
     * Gets the count.
     *
     * @return the count
     */
    public double getCount() {
	return count;
    }

    /**
     * Sets the count.
     *
     * @param count
     *            the new count
     */
    public void setCount(double count) {
	this.count = count;
    }

    /**
     * Gets the lower bound.
     *
     * @return the lower bound
     */
    public double getLowerBound() {
	return lowerBound;
    }

    /**
     * Sets the lower bound.
     *
     * @param lowerBound
     *            the new lower bound
     */
    public void setLowerBound(double lowerBound) {
	this.lowerBound = lowerBound;
    }

    /**
     * Instantiates a new gregory leibniz.
     *
     * @param input
     *            the input
     * @param nThreads
     *            the n threads
     * @param lowerBound
     *            the lower bound
     */
    public GregoryLeibniz(long input, int nThreads, double lowerBound) {
	this.lowerBound = lowerBound;
    }

    /**
     * Instantiates a new gregory leibniz.
     */
    public GregoryLeibniz() {
	super();
    }

    /*
     * (non-Javadoc)
     * 
     * @see multithread.interfaces.PiFormula#GregoryLeibnizFormula(long, int)
     */
    @Override
    public void GregoryLeibnizFormula(long input, int nThreads) {
	if (input <= 0) {
	    System.out.println("Your input is invalid");
	} else {
	    for (int i = (int) lowerBound; i < lowerBound + input / nThreads; i++) {
		count += Math.pow(-1, i) / (2 * i + 1);
	    }
	}
    }

    /**
     * Gets the sum.
     *
     * @return the sum
     */
    public double getSum() {
	return count;
    }
}
