package multithread.formula;

import multithread.interfaces.PiFormula;

public class GregoryLeibniz implements PiFormula {

	private double count = 0.0;
	private double lowerBound;

	public GregoryLeibniz(long input, int nThreads, double lowerBound) {
		this.lowerBound = lowerBound;
	}

	public GregoryLeibniz() {
		super();
	}

	@Override
	public void GregoryLeibnizFormula(long input, int nThreads) {
		if (input <= 0) {
			System.out.println("Your input is invalid");
		} else {
			for (double i = lowerBound; i < lowerBound + input / nThreads; i++) {
				count += Math.pow(-1, i) / (2 * i + 1);
			}
		}
	}

	public double getSum() {
		return count;
	}
}
