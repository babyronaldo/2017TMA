/*
 * 
 */
package multithread.interfaces;

public interface PiFormula {
    
    /**
     * Gregory leibniz formula.
     *
     * @param input the input
     * @param nThreads the n threads
     */
    public void GregoryLeibnizFormula(long input, int nThreads);
}
