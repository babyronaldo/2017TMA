package multithread.interfaces;

public interface PiFormula {
public void GregoryLeibnizFormula(long input,  int nThreads);
}
