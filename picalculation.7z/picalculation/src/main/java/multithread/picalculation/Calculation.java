package multithread.picalculation;

import java.util.ArrayList;
import java.util.List;

import multithread.formula.FormulaFactory;
import multithread.formula.GregoryLeibniz;

public class Calculation extends Thread {
	public double count = 0.0;
	public long input;
	public int nThreads;
	public double lowerBound;
	public List<Integer> countList = new ArrayList<Integer>();
	FormulaFactory formulaFactory = new FormulaFactory();

	@Override
	public void run() {
		GregoryLeibniz gregoryLeibniz = formulaFactory.getPi(input, nThreads);

		if (gregoryLeibniz == null)
			System.out.println("null");
		else {
			formulaFactory.getPi(input, nThreads);
			gregoryLeibniz.getSum();
		}
	}
}
