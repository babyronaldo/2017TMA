package multithread.picalculation;

import java.util.ArrayList;
import java.util.List;
import multithread.formula.FormulaFactory;
import multithread.formula.GregoryLeibniz;

public class Calculation extends Thread {
	public double count = 0.0;
	public long input;
	public int nThreads;
	public double lowerBound;
	public List<Integer> countList = new ArrayList<Integer>();

	@Override
	public void run() {
		FormulaFactory formulaFactory = new FormulaFactory();
		GregoryLeibniz gregoryLeibniz = formulaFactory.getPi(input, nThreads, lowerBound);
		count = gregoryLeibniz.getSum();
	}
}
