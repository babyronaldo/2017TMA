/*
 * 
 */
package multithread.picalculation;

import multithread.formula.FormulaFactory;
import multithread.formula.GregoryLeibniz;

public class Calculation extends Thread {

    /** The count. */
    public double count = 0.0;

    /** The input. */
    public long input;

    /** The n threads. */
    public int nThreads;

    /** The lower bound. */
    public double lowerBound;

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Thread#run()
     */
    @Override
    public void run() {
	FormulaFactory formulaFactory = new FormulaFactory();
	GregoryLeibniz gregoryLeibniz = formulaFactory.getPi(input, nThreads, lowerBound);
	count = gregoryLeibniz.getSum();
    }
}
