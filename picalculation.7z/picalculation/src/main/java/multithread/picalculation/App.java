package multithread.picalculation;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import multithread.formula.AbstractFactory;
import multithread.formula.FormulaFactory;
import multithread.formula.GregoryLeibniz;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		double pi = 0.0;
		Scanner sc = new Scanner(System.in);

		System.out.println("Insert your number: ");
		long input = sc.nextLong();
		
		System.out.println("App input: " + input);

		// System.out.println("How Many threads? ");
		int nThreads = 36;// Runtime.getRuntime().availableProcessors();
		final Calculation[] pThreads = new Calculation[nThreads];
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < nThreads; i++) {
			pThreads[i] = new Calculation();
			pThreads[i].input = input;
			pThreads[i].nThreads = nThreads;
			pThreads[i].lowerBound = (double) (input / nThreads * i);
			
			pThreads[i].start();
		}

		try {
			for (int i = 0; i < nThreads; i++) {
				pThreads[i].join();
				System.out.println("Thread " + i + " Prime count: " + pThreads[i].count);
			}
		} catch (InterruptedException e) {
		}
		//FormulaFactory formulaFactory = new FormulaFactory();

		//GregoryLeibniz gregoryLeibniz = formulaFactory.getPi(input, nThreads);
		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println("Execution time = " + elapsedTime/60);
		System.out.println("----------------------------------------------------");
		int cores = Runtime.getRuntime().availableProcessors();

		System.out.println("How many Cores this Java Program used: " + cores);
		// for (int i = 0; i < nThreads; i++)
		// System.out.println("Thread " + i + " Prime count: " +
		// pThreads[i].count); // Display
		// Thread
		// count

		
		List<Integer> allPrimes = new ArrayList<Integer>();
		for (Calculation p : pThreads) {
			allPrimes.addAll(p.countList);
		}
		System.out.println("Total prime count: " + allPrimes.size());
		for (Calculation p : pThreads) {
			// System.out.println(p.primeList);
			pi += p.count * 4;

		}
		System.out.println(pi);
	}
}
