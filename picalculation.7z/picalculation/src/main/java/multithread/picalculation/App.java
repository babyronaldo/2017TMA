package multithread.picalculation;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		double pi = 0.0;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);

		System.out.println("Insert your number: ");
		long input = sc.nextLong();

		// System.out.println("How Many threads? ");
		int nThreads = 36;// Runtime.getRuntime().availableProcessors();

		System.out.println("\nApp input: " + input + "  Threads: " + nThreads + "\n");

		final Calculation[] pThreads = new Calculation[nThreads];
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < nThreads; i++) {
			pThreads[i] = new Calculation();
			pThreads[i].input = input;
			pThreads[i].lowerBound = (double) (input / nThreads * i);
			pThreads[i].nThreads = nThreads;
			pThreads[i].start();
		}

		try {
			for (int i = 0; i < nThreads; i++) {
				pThreads[i].join();
				System.out.println("Thread " + i + " Pi count: " + pThreads[i].count);
			}
		} catch (InterruptedException e) {
		}
		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println("\nExecution time = " + elapsedTime);
		System.out.println("----------------------------------------------------");
		int cores = Runtime.getRuntime().availableProcessors();

		System.out.println("How many Cores this Java Program used: " + cores);

		for (Calculation p : pThreads) {
			pi += p.count * 4;
		}
		System.out.println("Pi: " + pi);
	}
}
