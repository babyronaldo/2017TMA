/*
 * 
 */
package multithread.formula;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class GregoryLeibnizTest extends TestCase {
    
    /** The gregory leibniz. */
    private GregoryLeibniz gregoryLeibniz;

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    @Before
    public void setUp() {
	gregoryLeibniz = new GregoryLeibniz();
    }

    /**
     * Test pi.
     */
    @Test
    public void testPi() {
	double piActual = 0.0;
	double piExpected = 0.0;
	double tolerance = 0.01;

	for (int i = 0; i < 100; i++) {
	    piExpected += Math.pow(-1, i) / (2 * i + 1) * 4;
	}
	gregoryLeibniz.GregoryLeibnizFormula(100, 1);
	piActual = gregoryLeibniz.getSum() * 4;

	Assert.assertEquals(piExpected, piActual, tolerance);
	Assert.assertTrue(Math.abs(piExpected - piActual) <= tolerance);
    }
}
