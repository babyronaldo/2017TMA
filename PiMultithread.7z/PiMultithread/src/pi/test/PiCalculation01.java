package pi.test;

import java.util.Scanner;

public class PiCalculation01 {

	public static void main(String... args) throws InterruptedException {

		int threadCount = 4;
		int N = 100000_000;
		PiThread[] threads = new PiThread[threadCount];
		for (int i = 0; i < threadCount; i++) {
			threads[i] = new PiThread(threadCount, i, N);
			threads[i].start();
		}
		for (int i = 0; i < threadCount; i++) {
			threads[i].join();
		}
		double pi = 0;
		for (int i = 0; i < threadCount; i++) {
			pi += threads[i].getSum();
		}
		System.out.print("PI = " + pi * 4);

	}

	// PI = 3.1415926635966116
	// PI = 3.141602653489967
	static class PiThread extends Thread {

		private final int threadCount;
		private final int threadRemainder;
		private final int N;
		private double sum = 0;

		public PiThread(int threadCount, int threadRemainder, int n) {
			this.threadCount = threadCount;
			this.threadRemainder = threadRemainder;
			N = n;
		}

		@Override
		public void run() {
			for (int i = 0; i <= N; i++) {
				if (i % threadCount == threadRemainder) {
					sum += Math.pow(-1, i) / (2 * i + 1);
				}
			}
		}

		// public void run() {
		// for (int i = threadRemainder; i <= N; i += threadCount) {
		// sum += Math.pow(-1, i) / (2 * i + 1);
		// }
		// }
		public double getSum() {
			return sum;
		}
	}
}
