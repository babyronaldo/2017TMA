package hien.tma.PiCalculate;

//Gregory and Leibniz Formula
public interface GregoryLeibnizFormula {

	public void GregoryLeibnizFormula();
	
}
