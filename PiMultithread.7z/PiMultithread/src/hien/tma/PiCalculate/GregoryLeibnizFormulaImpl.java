package hien.tma.PiCalculate;

import java.util.concurrent.atomic.AtomicLong;

public class GregoryLeibnizFormulaImpl implements GregoryLeibnizFormula {


	@Override
	public void GregoryLeibnizFormula() {
//		return 0;		
	}

}
