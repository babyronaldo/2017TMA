package hien.tma.PiCalculate;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicLong;

public class FormulaWorker {
	public static volatile boolean running = true;

	public static void main(String[] args) throws InterruptedException {
		long timeoutMs = 40_000;
		double pi = 0.0;
		final AtomicLong counter = new AtomicLong(0);

		PiCalculation[] pThreads = new PiCalculation[4];
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < 4; i++) {
			pThreads[i] = new PiCalculation(counter);
			pThreads[i].start();
		}
		Thread.sleep(timeoutMs);
		running = false;
		try {
			for (int i = 0; i < 4; i++)
				pThreads[i].join();
		} catch (InterruptedException e) {
		}
		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println("Execution time = " + elapsedTime);
		System.out.println("----------------------------------------------------");
		int cores = Runtime.getRuntime().availableProcessors();

		System.out.println("How many Cores this Java Program used: " + cores);

		int active = Thread.activeCount();
		System.out.println(active);
		// List<Integer> allPrimes = new ArrayList<>();
		// for (Prime p : pThreads) {
		// allPrimes.addAll(p.primeList);
		// }
		// System.out.println("Total prime count: " + allPrimes.size());
		for (PiCalculation p : pThreads) {
			// System.out.println(p.primeList);
			pi += p.getSum() * 4;

		}
		System.out.println(pi);
	}

	static class PiCalculation extends Thread {

		private AtomicLong counter;
		private double sum = 0.0;

		public PiCalculation(AtomicLong counter) {
			this.counter = counter;
		}

		@Override
		public void run() {
			long i;
			while (running && isValidCounter(i = counter.getAndAdd(1))) {
				sum += Math.pow(-1, i) / (2 * i + 1);
			}
		}

		private boolean isValidCounter(long value) {
			return value >= 0 && value < Long.MAX_VALUE;
		}

		public double getSum() {
			return sum;
		}
	}
}
