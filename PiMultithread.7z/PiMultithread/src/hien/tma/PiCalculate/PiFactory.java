package hien.tma.PiCalculate;

public class PiFactory extends AbstractFactory{

	@Override
	GregoryLeibnizFormula getSum(double sum) {
		// TODO Auto-generated method stub
		return null;
	}

}
