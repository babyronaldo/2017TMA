package hien.tma.PiCalculate;

import java.util.concurrent.atomic.AtomicLong;

public class PiCalculationTest extends Thread {
	public static volatile boolean running = true;

	private GregoryLeibnizFormula gregoryLeibnizFormula;

	private AtomicLong counter;
	private double sum = 0.0;

	public PiCalculationTest(AtomicLong counter) {
		this.counter = counter;
	}

	@Override
	public void run() {

		long i;

		while (running && isValidCounter(i = counter.getAndAdd(1))) {
			gregoryLeibnizFormula.GregoryLeibnizFormula(i);
		}
	}

	private boolean isValidCounter(long value) {
		return value >= 0 && value < Long.MAX_VALUE;
	}

	public double getSum() {
		return sum;
	}
}
