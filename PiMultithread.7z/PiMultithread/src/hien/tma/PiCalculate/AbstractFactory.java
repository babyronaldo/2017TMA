package hien.tma.PiCalculate;

public abstract class AbstractFactory {

	abstract GregoryLeibnizFormula getSum(double sum);

}
