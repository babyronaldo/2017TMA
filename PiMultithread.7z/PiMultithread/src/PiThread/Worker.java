package PiThread;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Worker {
	public static void main(String[] args) {
		int active = Thread.activeCount();
		System.out.println(active);
		double pi = 0.0;
		Scanner scan = new Scanner(System.in);

		System.out.println("Insert your number: ");
		long input = scan.nextLong();

		// System.out.println("How Many threads? ");
		int nThreads = 36;// Runtime.getRuntime().availableProcessors();

		final Prime[] pThreads = new Prime[nThreads];
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < nThreads; i++) {
			pThreads[i] = new Prime();
			pThreads[i].input = input;
			pThreads[i].lowerBound = (double) (input / nThreads * i);
			pThreads[i].temp = nThreads;
			pThreads[i].start();
		}

		try {
			for (int i = 0; i < nThreads; i++) {
				pThreads[i].join();
				System.out.println("Thread " + i + " Prime count: " + pThreads[i].count);
			}
		} catch (InterruptedException e) {
		}
		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println("Execution time = " + elapsedTime/60);
		System.out.println("----------------------------------------------------");
		int cores = Runtime.getRuntime().availableProcessors();

		System.out.println("How many Cores this Java Program used: " + cores);
		// for (int i = 0; i < nThreads; i++)
		// System.out.println("Thread " + i + " Prime count: " +
		// pThreads[i].count); // Display
		// Thread
		// count

		System.out.println(active);
		List<Integer> allPrimes = new ArrayList<>();
		for (Prime p : pThreads) {
			allPrimes.addAll(p.primeList);
		}
		System.out.println("Total prime count: " + allPrimes.size());
		for (Prime p : pThreads) {
			// System.out.println(p.primeList);
			pi += p.count * 4;

		}
		System.out.println(pi);
	}
}