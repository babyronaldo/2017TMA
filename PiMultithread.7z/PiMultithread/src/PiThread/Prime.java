package PiThread;

import java.math.BigInteger;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Prime extends Thread {
	public double count = 0.0;
	public long input;
	public int temp;
	public double lowerBound;
	public List<Integer> primeList = new ArrayList<>();

	@Override
	public void run() {
		Scanner sc = new Scanner(System.in);
		for (double i = lowerBound; i < lowerBound + input / temp; i++) {
			count += Math.pow(-1, i) / (2 * i + 1);
		}
	}
}